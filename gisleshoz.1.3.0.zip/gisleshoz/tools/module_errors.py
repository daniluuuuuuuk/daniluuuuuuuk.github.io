MODULE_ERROR = 'Ошибка ГИСлесхоз'
CONFIG_FILE_ERROR = "Не удается корректно прочитать файл настроек.\n"
DATABASE_CONNECTION_ERROR = "Невозможно установить подключение к базе данных.\n "
DBMS_CONNECTION_ERROR = "Невозможно установить подключение к СУБД.\n "
FILTER_DISABLED = ' Фильтр поиска отключен. \n'
CONNECTION_SUCCEEDED = "Подключение успешно установлено. Настройки можно сохранить.\n "
INPUT_DATA_NOT_VALID = "Введены не все данные. Пожалуйста, проверьте \n"